//: Playground - noun: a place where people can play

import UIKit

var foo = 17 + 34

foo += 1

foo = foo + 1

foo -= 1

foo = foo - 1

var bar = 9/2

bar = 9 % 2



