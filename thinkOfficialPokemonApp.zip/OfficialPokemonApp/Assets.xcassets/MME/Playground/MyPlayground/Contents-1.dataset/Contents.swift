//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


var result = 5 + 5
result = 7 - 2
result = 7 * 49
result = 10 / 2
var newResult = result * s100
var order = 3 + 5 * 10
order = (3 + 5) * 10
