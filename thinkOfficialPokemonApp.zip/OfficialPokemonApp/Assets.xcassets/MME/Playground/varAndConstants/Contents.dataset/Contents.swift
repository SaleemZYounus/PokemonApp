//: Playground - noun: a place where people can play

import UIKit

var numberofStudentsInClass = 50
numberofStudentsInClass = 1000

let theSause = 108
print(theSause)



// Sussame

/*rungertheerungertheerungertheereeerungertheerunger
 theerungertheerungertheerungertheerungertheerungerthee/*
 
 
 */*/

var x = 3
var y = 2
var z = 1


