//: Playground - noun: a place where people can play

import UIKit

var granolaBar :Int = 5
var cookiesInMe :Double = 5.0
var doodleBook :Float = 78.0

var stringTypes :String = "This is a string."


//Infered  interger, integer because whole num
var yeelime = 15
//Infered  interger, integer because decimal
var treeslime = 6.3
//Infered string, stringbecause quotation
var me = "me"
//BOOLDEAN
var lifeISLIFE = true

let age = 15
print ("my age is\(age)")

var inferedIntegerArray = [2,5,6,8,17]

var arrayOfStrings = ("iceCream")

s
