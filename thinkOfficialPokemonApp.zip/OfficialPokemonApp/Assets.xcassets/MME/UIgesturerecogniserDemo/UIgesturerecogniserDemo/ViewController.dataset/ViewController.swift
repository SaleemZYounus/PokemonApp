//
//  ViewController.swift
//  UIgesturerecogniserDemo
//
//  Created by Saleem Younus (Student) on 11/27/18.
//  Copyright © 2018 Grayslake Central Highschool. All rights reserved.
//

import UIKit

class ViewController: UIViewController {


    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

   


}

