//
//  ViewController.swift
//  firstFlashlightApp
//
//  Created by Saleem Younus (Student) on 8/23/18.
//  Copyright © 2018 Grayslake Central Highschool. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    @IBAction func OnButtonTap(_ sender: UIButton) { self.view.backgroundColor = UIColor.purple
    }
   
}
