//
//  ViewController.swift
//  scoping Demo
//
//  Created by Saleem Younus (Student) on 11/5/18.
//  Copyright © 2018 Grayslake Central Highschool. All rights reserved.
//

import UIKit




var name = String()
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    name = "Saleem"
        
        
        
        var lastName =
        String()
    
    func updatedName ()
    {
   
name = "Seelam"
        lastName = "Sounus"
        
        print (lastName)
        }
     updatedName ()
    }
   
    
    

}

